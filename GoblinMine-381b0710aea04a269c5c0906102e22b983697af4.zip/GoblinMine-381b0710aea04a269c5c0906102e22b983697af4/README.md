# GoblinMine

BOT LINK: [Link Bot](https://t.me/GoblinMine_bot/start?startapp=5373988314)

TELEGRAM GROUP LINK: [Link Channel Telegram](https://t.me/UxScript)

## Features:
| Feature                        | Supported |
|--------------------------------|:---------:|
| Multithreading                 |     ✔     |
| Auto ref                       |     ✔     |
| Night mod                      |     ✔     |
| Auto upgrade mine              |     ✔     |
| Auto upgrade miners            |     ✔     |
| Auto upgrade inventory         |     ✔     |
| Auto upgrade cart              |     ✔     |
| Auto expedition                |     ✔     |
| Support for pyrogram .session  |     ✔     |

## Upcoming Features:
- (Coming Soon)

## Installation

## TERMUX
### Install the required libraries:
```bash
python3 -m pip install -r requirements.txt
```
### Run the Bot   
```bash
python3 main.py
```

## WINDOWS
### Install the required libraries:
```bash
pip install -r requirements.txt
```
### Run the Bot   
```bash
python main.py
```

Don’t forget to star the project and report any bugs you find. Good luck!
